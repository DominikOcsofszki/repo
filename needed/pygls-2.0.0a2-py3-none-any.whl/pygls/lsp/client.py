from ._base_client import BaseLanguageClient


# Placeholder for when we add a real client
class LanguageClient(BaseLanguageClient):
    """Language client."""
