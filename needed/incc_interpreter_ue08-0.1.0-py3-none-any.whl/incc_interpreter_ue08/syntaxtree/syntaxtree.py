# from dataclasses import dataclass


# @dataclass
class Expression:
    pass
