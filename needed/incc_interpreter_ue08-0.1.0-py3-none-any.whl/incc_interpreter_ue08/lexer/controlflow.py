controlflow_reserved_words = {
    'IF', 'THEN', 'ELSE', 
    'LOOP', 'FOR',
    'WHILE', 'DO'
}
