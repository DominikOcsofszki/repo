seq_tokens = {"LBRACE", "RBRACE", "SEMICOLON"}


def t_LBRACE(t):
    "{"
    return t


def t_RBRACE(t):
    "}"
    return t


# t_LBRACE = '{'
# t_RBRACE = '}'
# t_SEMICOLON = ";"
def t_SEMICOLON(t):
    ";"
    return t
