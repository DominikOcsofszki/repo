var_tokens = {
    'ASSIGN'
}
var_reserved_words = {
    'LOCK', 'LOCAL', 'IN'
}


t_ASSIGN = '='
