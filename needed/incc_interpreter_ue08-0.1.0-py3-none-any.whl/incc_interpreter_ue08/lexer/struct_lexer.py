struct_tokens = {"DOT"}
struct_reserved_words = {"STRUCT", "EXTEND", "SET", "THIS"}


# t_DOT = r"\."
# TODO: change to get more info into lexer
def t_DOT(t):
    r"\."
    return t
