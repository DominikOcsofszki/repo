import argparse

from incc_interpreter_ue08 import interpreter


def main():
    argparser = argparse.ArgumentParser(
        prog="interpreter", description="Run the interpreter"
    )
    argparser.add_argument("file", type=str, nargs="?", help="The file to interpret")
    argparser.add_argument(
        "--repl", action="store_true", help="Run the interpreter in REPL mode"
    )
    argparser.add_argument(
        "--stop-on-error", action="store_true", help="Stop the repl on error"
    )

    args = argparser.parse_args()
    if args.stop_on_error and not args.repl:
        argparser.error("--stop-on-error requires --repl")

    interpreter.main(args)
