# from dataclasses import dataclass
#
# from incc_interpreter_ue08.syntaxtree.syntaxtree import Expression
#
#
# @dataclass
# class CommentExpression(Expression):
#     comment: str
#
#
# def p_expression_commentss(p):
#     """
#     expression  : COMMENT SEMICOLON
#                 | COMMENT
#     """
#     p[0] = CommentExpression(p[1])
#     print("ASDSAD")
#     exit()
