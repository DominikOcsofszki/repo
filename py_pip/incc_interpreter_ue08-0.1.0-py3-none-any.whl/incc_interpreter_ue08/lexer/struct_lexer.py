struct_tokens = {"DOT"}
struct_reserved_words = {"STRUCT", "EXTEND", "SET", "THIS"}

t_DOT = r"\."
