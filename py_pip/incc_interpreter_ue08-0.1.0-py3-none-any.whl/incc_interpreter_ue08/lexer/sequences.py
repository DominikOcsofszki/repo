seq_tokens = {
    'LBRACE',
    'RBRACE',
    'SEMICOLON'
}


t_LBRACE = '{'
t_RBRACE = '}'
t_SEMICOLON = ';'
