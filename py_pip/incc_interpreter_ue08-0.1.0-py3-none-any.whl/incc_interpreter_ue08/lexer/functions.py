functions_tokens = {
    'RIGHT_ARROW', 'BACKSLASH'
}
functions_reserved_words = {
    'FUN',
}

t_RIGHT_ARROW = r'->'
t_BACKSLASH = r'\\'
